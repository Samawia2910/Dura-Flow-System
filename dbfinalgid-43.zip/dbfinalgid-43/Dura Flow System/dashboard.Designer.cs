﻿
namespace Dura_Flow_System
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.staffManage = new System.Windows.Forms.Button();
            this.Gatepass = new System.Windows.Forms.Button();
            this.Transport = new System.Windows.Forms.Button();
            this.Sales = new System.Windows.Forms.Button();
            this.production = new System.Windows.Forms.Button();
            this.stock = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Logout = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.staffManage);
            this.panel1.Controls.Add(this.Gatepass);
            this.panel1.Controls.Add(this.Transport);
            this.panel1.Controls.Add(this.Sales);
            this.panel1.Controls.Add(this.production);
            this.panel1.Controls.Add(this.stock);
            this.panel1.Controls.Add(this.panelLogo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 745);
            this.panel1.TabIndex = 0;
            // 
            // staffManage
            // 
            this.staffManage.BackColor = System.Drawing.Color.SteelBlue;
            this.staffManage.Dock = System.Windows.Forms.DockStyle.Top;
            this.staffManage.FlatAppearance.BorderSize = 0;
            this.staffManage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.staffManage.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.staffManage.ForeColor = System.Drawing.Color.White;
            this.staffManage.Image = ((System.Drawing.Image)(resources.GetObject("staffManage.Image")));
            this.staffManage.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.staffManage.Location = new System.Drawing.Point(0, 410);
            this.staffManage.Name = "staffManage";
            this.staffManage.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.staffManage.Size = new System.Drawing.Size(250, 70);
            this.staffManage.TabIndex = 6;
            this.staffManage.Text = "   Staff Management";
            this.staffManage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.staffManage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.staffManage.UseVisualStyleBackColor = false;
            this.staffManage.Click += new System.EventHandler(this.Staff_Click);
            // 
            // Gatepass
            // 
            this.Gatepass.BackColor = System.Drawing.Color.SteelBlue;
            this.Gatepass.Dock = System.Windows.Forms.DockStyle.Top;
            this.Gatepass.FlatAppearance.BorderSize = 0;
            this.Gatepass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Gatepass.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gatepass.ForeColor = System.Drawing.Color.White;
            this.Gatepass.Image = ((System.Drawing.Image)(resources.GetObject("Gatepass.Image")));
            this.Gatepass.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Gatepass.Location = new System.Drawing.Point(0, 350);
            this.Gatepass.Name = "Gatepass";
            this.Gatepass.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.Gatepass.Size = new System.Drawing.Size(250, 60);
            this.Gatepass.TabIndex = 5;
            this.Gatepass.Text = "   Gatepass";
            this.Gatepass.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Gatepass.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Gatepass.UseVisualStyleBackColor = false;
            this.Gatepass.Click += new System.EventHandler(this.gatepass_Click);
            // 
            // Transport
            // 
            this.Transport.BackColor = System.Drawing.Color.SteelBlue;
            this.Transport.Dock = System.Windows.Forms.DockStyle.Top;
            this.Transport.FlatAppearance.BorderSize = 0;
            this.Transport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Transport.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Transport.ForeColor = System.Drawing.Color.White;
            this.Transport.Image = ((System.Drawing.Image)(resources.GetObject("Transport.Image")));
            this.Transport.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Transport.Location = new System.Drawing.Point(0, 290);
            this.Transport.Name = "Transport";
            this.Transport.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.Transport.Size = new System.Drawing.Size(250, 60);
            this.Transport.TabIndex = 4;
            this.Transport.Text = "   Transport Department";
            this.Transport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Transport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Transport.UseVisualStyleBackColor = false;
            this.Transport.Click += new System.EventHandler(this.button1_Click);
            // 
            // Sales
            // 
            this.Sales.BackColor = System.Drawing.Color.SteelBlue;
            this.Sales.Dock = System.Windows.Forms.DockStyle.Top;
            this.Sales.FlatAppearance.BorderSize = 0;
            this.Sales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sales.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sales.ForeColor = System.Drawing.Color.White;
            this.Sales.Image = ((System.Drawing.Image)(resources.GetObject("Sales.Image")));
            this.Sales.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Sales.Location = new System.Drawing.Point(0, 230);
            this.Sales.Name = "Sales";
            this.Sales.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.Sales.Size = new System.Drawing.Size(250, 60);
            this.Sales.TabIndex = 2;
            this.Sales.Text = "   Sales Management";
            this.Sales.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Sales.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Sales.UseVisualStyleBackColor = false;
            this.Sales.Click += new System.EventHandler(this.Sales_Click);
            // 
            // production
            // 
            this.production.BackColor = System.Drawing.Color.SteelBlue;
            this.production.Dock = System.Windows.Forms.DockStyle.Top;
            this.production.FlatAppearance.BorderSize = 0;
            this.production.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.production.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.production.ForeColor = System.Drawing.Color.White;
            this.production.Image = ((System.Drawing.Image)(resources.GetObject("production.Image")));
            this.production.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.production.Location = new System.Drawing.Point(0, 170);
            this.production.Name = "production";
            this.production.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.production.Size = new System.Drawing.Size(250, 60);
            this.production.TabIndex = 1;
            this.production.Text = "   Production Department";
            this.production.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.production.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.production.UseVisualStyleBackColor = false;
            this.production.Click += new System.EventHandler(this.production_Click);
            // 
            // stock
            // 
            this.stock.BackColor = System.Drawing.Color.SteelBlue;
            this.stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.stock.FlatAppearance.BorderSize = 0;
            this.stock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stock.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stock.ForeColor = System.Drawing.Color.White;
            this.stock.Image = ((System.Drawing.Image)(resources.GetObject("stock.Image")));
            this.stock.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stock.Location = new System.Drawing.Point(0, 100);
            this.stock.Name = "stock";
            this.stock.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.stock.Size = new System.Drawing.Size(250, 70);
            this.stock.TabIndex = 0;
            this.stock.Text = "   Stock Management";
            this.stock.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stock.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.stock.UseVisualStyleBackColor = false;
            this.stock.Click += new System.EventHandler(this.stock_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.White;
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(250, 100);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(44, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(157, 46);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.Controls.Add(this.Logout);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(250, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(841, 100);
            this.panel2.TabIndex = 1;
            // 
            // Logout
            // 
            this.Logout.BackColor = System.Drawing.Color.SkyBlue;
            this.Logout.Dock = System.Windows.Forms.DockStyle.Right;
            this.Logout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Logout.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logout.Location = new System.Drawing.Point(715, 0);
            this.Logout.Name = "Logout";
            this.Logout.Size = new System.Drawing.Size(126, 100);
            this.Logout.TabIndex = 1;
            this.Logout.Text = "LOGOUT";
            this.Logout.UseVisualStyleBackColor = false;
            this.Logout.Click += new System.EventHandler(this.Logout_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Ivory;
            this.label1.Location = new System.Drawing.Point(144, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(526, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "   DURA FLOW  PLASTICS and PIPES";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(250, 100);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(841, 645);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SteelBlue;
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 480);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(250, 70);
            this.button1.TabIndex = 7;
            this.button1.Text = "   Reports";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1091, 745);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.dashboard_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Sales;
        private System.Windows.Forms.Button production;
        private System.Windows.Forms.Button stock;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Transport;
        private System.Windows.Forms.Button Gatepass;
        private System.Windows.Forms.Button staffManage;
        private System.Windows.Forms.Button Logout;
        private System.Windows.Forms.Button button1;
    }
}