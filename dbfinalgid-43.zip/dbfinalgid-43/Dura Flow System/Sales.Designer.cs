﻿
namespace Dura_Flow_System
{
    partial class Sales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sales));
            this.panel1 = new System.Windows.Forms.Panel();
            this.B2B = new System.Windows.Forms.Button();
            this.saleReturn = new System.Windows.Forms.Button();
            this.saleGoods = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.mainpanel = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.mainpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.B2B);
            this.panel1.Controls.Add(this.saleReturn);
            this.panel1.Controls.Add(this.saleGoods);
            this.panel1.Controls.Add(this.panelLogo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 622);
            this.panel1.TabIndex = 0;
            // 
            // B2B
            // 
            this.B2B.BackColor = System.Drawing.Color.SteelBlue;
            this.B2B.Dock = System.Windows.Forms.DockStyle.Top;
            this.B2B.FlatAppearance.BorderSize = 0;
            this.B2B.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B2B.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2B.ForeColor = System.Drawing.Color.White;
            this.B2B.Image = ((System.Drawing.Image)(resources.GetObject("B2B.Image")));
            this.B2B.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.B2B.Location = new System.Drawing.Point(0, 300);
            this.B2B.Name = "B2B";
            this.B2B.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.B2B.Size = new System.Drawing.Size(250, 100);
            this.B2B.TabIndex = 2;
            this.B2B.Text = "      Branch to Branch";
            this.B2B.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.B2B.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.B2B.UseVisualStyleBackColor = false;
            this.B2B.Click += new System.EventHandler(this.button1_Click);
            // 
            // saleReturn
            // 
            this.saleReturn.BackColor = System.Drawing.Color.SteelBlue;
            this.saleReturn.Dock = System.Windows.Forms.DockStyle.Top;
            this.saleReturn.FlatAppearance.BorderSize = 0;
            this.saleReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saleReturn.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saleReturn.ForeColor = System.Drawing.Color.White;
            this.saleReturn.Image = ((System.Drawing.Image)(resources.GetObject("saleReturn.Image")));
            this.saleReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saleReturn.Location = new System.Drawing.Point(0, 200);
            this.saleReturn.Name = "saleReturn";
            this.saleReturn.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.saleReturn.Size = new System.Drawing.Size(250, 100);
            this.saleReturn.TabIndex = 1;
            this.saleReturn.Text = "    Sales Return";
            this.saleReturn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saleReturn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.saleReturn.UseVisualStyleBackColor = false;
            this.saleReturn.Click += new System.EventHandler(this.production_Click);
            // 
            // saleGoods
            // 
            this.saleGoods.BackColor = System.Drawing.Color.SteelBlue;
            this.saleGoods.Dock = System.Windows.Forms.DockStyle.Top;
            this.saleGoods.FlatAppearance.BorderSize = 0;
            this.saleGoods.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saleGoods.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saleGoods.ForeColor = System.Drawing.Color.White;
            this.saleGoods.Image = ((System.Drawing.Image)(resources.GetObject("saleGoods.Image")));
            this.saleGoods.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saleGoods.Location = new System.Drawing.Point(0, 100);
            this.saleGoods.Name = "saleGoods";
            this.saleGoods.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.saleGoods.Size = new System.Drawing.Size(250, 100);
            this.saleGoods.TabIndex = 0;
            this.saleGoods.Text = "    Sales";
            this.saleGoods.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saleGoods.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.saleGoods.UseVisualStyleBackColor = false;
            this.saleGoods.Click += new System.EventHandler(this.stock_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.White;
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(250, 100);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(36, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 54);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SteelBlue;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(250, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(771, 100);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Ivory;
            this.label1.Location = new System.Drawing.Point(193, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(381, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "   SALES  DEPARTMENT";
            // 
            // mainpanel
            // 
            this.mainpanel.Controls.Add(this.pictureBox2);
            this.mainpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainpanel.Location = new System.Drawing.Point(250, 100);
            this.mainpanel.Name = "mainpanel";
            this.mainpanel.Size = new System.Drawing.Size(771, 522);
            this.mainpanel.TabIndex = 2;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(771, 522);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SteelBlue;
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Bookman Old Style", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 400);
            this.button1.Name = "button1";
            this.button1.Padding = new System.Windows.Forms.Padding(11, 0, 0, 0);
            this.button1.Size = new System.Drawing.Size(250, 100);
            this.button1.TabIndex = 3;
            this.button1.Text = "      Bill";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Sales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1021, 622);
            this.Controls.Add(this.mainpanel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Sales";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.dashboard_FormClosing);
            this.Load += new System.EventHandler(this.StockManage_Load);
            this.panel1.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.mainpanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button saleReturn;
        private System.Windows.Forms.Button saleGoods;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel mainpanel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button B2B;
        private System.Windows.Forms.Button button1;
    }
}